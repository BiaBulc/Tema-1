package ro.emanuel.magazin.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import ro.emanuel.magazin.dao.ProdusDAO;
import ro.emanuel.magazin.pojo.Produs;

@Controller
public class ProduseController {
	
	@RequestMapping (value="produse.htm")
	public ModelAndView showProducts() throws SQLException, ClassNotFoundException{
		ModelMap model= new ModelMap();
		
		ArrayList<Produs> products = ProdusDAO.getProducts();
		model.addAttribute("produseList", products);
		
		return new ModelAndView("/produse/listare", "model",model);
	}

		
		@RequestMapping(value = "/produse/detalii/{produsId}")
		public ModelAndView vizualizareDetalii(@PathVariable String produsId, Model model)
				throws NumberFormatException, SQLException {

			Produs p = ProdusDAO.getProductById(Integer.parseInt(produsId));
			model.addAttribute("product", p);

			return new ModelAndView("/produse/detalii", "model", model);
		}

		@RequestMapping(value = "/produse/editeaza/{produsId}")
		public ModelAndView editDetalii(@PathVariable String produsId, Model model)
				throws NumberFormatException, SQLException {

			Produs p = ProdusDAO.getProductById(Integer.parseInt(produsId));
			model.addAttribute("productForm", p);

			return new ModelAndView("/produse/edit", "model", model);
		}

		@RequestMapping(value = "/produse/save", method = RequestMethod.POST)
		public ModelAndView saveProduct(@ModelAttribute("productForm") Produs produs, ModelMap model, BindingResult result) {

			Produs produsObj;
			try {
				produsObj = ProdusDAO.getProductById(Integer.valueOf(produs.getId()));
				produsObj.setUtilizatorid(produs.getUtilizatorid());
				produsObj.setNumeprodus(produs.getNumeprodus());
				produsObj.setStoc(produs.getStoc());
				produsObj.setPret(produs.getPret());
				ProdusDAO.updateProduct(produsObj);
				model.put("productForm", produs);
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (SQLException e) {
			    e.printStackTrace();
			}

			return new ModelAndView("/produse/editeaza", "command", produs);
		}

		@RequestMapping(value = "/produse/stergere/{produsId}")
		public ModelAndView deleteProduct(@PathVariable String produsId, Model model)
				throws NumberFormatException, SQLException {

			ProdusDAO.deleteProduct
			(ProdusDAO.getProductById(Integer.parseInt(produsId)));
			ArrayList<Produs> products = ProdusDAO.getProducts();
			model.addAttribute("produseList", products);

			return new ModelAndView("/products/list", "model", model);
		}

		@RequestMapping(value = "/products/adauga")
		public ModelAndView adaugaProduct(Model model) throws NumberFormatException, SQLException {

			Produs p = new Produs(0, 0, null, 0, 0);
			model.addAttribute("productForm", p);

			return new ModelAndView("/produse/add", "model", model);
		}

		@RequestMapping(value = "/produse/addProduct", method = RequestMethod.POST)
		public ModelAndView addProduct(@ModelAttribute("productForm") Produs produs, ModelMap model, BindingResult result) {

			try {
				ProdusDAO.createProduct(produs);
				model.put("productForm", produs);
			} catch (NumberFormatException e) {
			
				e.printStackTrace();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}

			return new ModelAndView("redirect:/produse.htm");
		}

	}