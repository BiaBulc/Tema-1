package ro.emanuel.magazin.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import ro.emanuel.magazin.dao.ComandaDAO;
import ro.emanuel.magazin.pojo.Comanda;

@Controller
public class ComenziController {
	
	@RequestMapping (value="comenzi.htm")
	public ModelAndView showOrders() throws SQLException, ClassNotFoundException{
		ModelMap model=new ModelMap();
		
		ArrayList<Comanda> orders=ComandaDAO.getOrders();
		model.addAttribute("orderList", orders);
		
		return new ModelAndView("/comenzi/listare", "model",model);
	}

		
		@RequestMapping(value = "/orders/detalii/{orderId}")
		public ModelAndView vizualizareDetalii(@PathVariable String orderId, Model model)
				throws NumberFormatException, SQLException {

			Comanda o = ComandaDAO.getOrderById(Integer.parseInt(orderId));
			model.addAttribute("order", o);

			return new ModelAndView("/comenzi/detalii", "model", model);
		}

		@RequestMapping(value = "/comenzi/editeaza/{comandaId}")
		public ModelAndView editDetalii(@PathVariable String comandaId, Model model)
				throws NumberFormatException, SQLException {

			Comanda o = ComandaDAO.getOrderById(Integer.parseInt(comandaId));
			model.addAttribute("orderForm", o);

			return new ModelAndView("/comenzi/editeaza", "model", model);
		}

		@RequestMapping(value = "/comenzi/save", method = RequestMethod.POST)
		public ModelAndView saveOrder(@ModelAttribute("orderForm") Comanda comanda, ModelMap model, BindingResult result) {

			Comanda comandaObj;
			try {
				comandaObj = ComandaDAO.getOrderById(Integer.valueOf(comanda.getId()));
				comandaObj.setProdusid(comanda.getProdusid());
				comandaObj.setUtilizatorid(comanda.getUtilizatorid());
				comandaObj.setData(comanda.getData());
				ComandaDAO.updateOrder(comandaObj);
				model.put("orderForm", comanda);
			} catch (NumberFormatException e) {
				
				e.printStackTrace();
			} catch (SQLException e) {
			
				e.printStackTrace();
			}

			return new ModelAndView("/comenzi/edit", "command", comanda);
		}

		@RequestMapping(value = "/comenzi/stergere/{comandaId}")
		public ModelAndView deleteOrder(@PathVariable String comandaId, Model model)
				throws NumberFormatException, SQLException {

			ComandaDAO.deleteOrder
			(ComandaDAO.getOrderById(Integer.parseInt(comandaId)));
			ArrayList<Comanda> comenzi = ComandaDAO.getOrders();
			model.addAttribute("ordersList", comenzi);

			return new ModelAndView("/comenzi/order", "model", model);
		}

		@RequestMapping(value = "/comenzi/adauga")
		public ModelAndView adaugaOrder(Model model) throws NumberFormatException, SQLException {

			Comanda o = new Comanda(0, 0, 0, null);
			model.addAttribute("orderForm", o);

			return new ModelAndView("/comenzi/add", "model", model);
		}

		@RequestMapping(value = "/comenzi/addOrder", method = RequestMethod.POST)
		public ModelAndView addOrder(@ModelAttribute("orderForm") Comanda comanda, ModelMap model, BindingResult result) {

			try {
				ComandaDAO.createOrder(comanda);
				model.put("orderForm", comanda);
			} catch (NumberFormatException e) {
			
				e.printStackTrace();
			} catch (SQLException e) {
			
				e.printStackTrace();
			}

		
			return new ModelAndView("redirect:/comenzi.htm");
		}

	}

