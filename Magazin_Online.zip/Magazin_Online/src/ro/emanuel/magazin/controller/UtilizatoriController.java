package ro.emanuel.magazin.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import ro.emanuel.magazin.dao.UtilizatorDAO;
import ro.emanuel.magazin.pojo.Utilizator;

@Controller
public class UtilizatoriController {

	@RequestMapping(value = "utilizatori.htm")
	public ModelAndView showUsers() throws SQLException {
		ModelMap model = new ModelMap();

		ArrayList<Utilizator> users = UtilizatorDAO.getUsers();
		model.addAttribute("utilizatoriList", users);

		return new ModelAndView("/utilizatori/listare", "model", model);

	}

	@RequestMapping(value = "/utilizatori/detalii/{utilizatoriId}")
	public ModelAndView vizualizareDetalii(@PathVariable String utilizatoriId, Model model)
			throws NumberFormatException, SQLException {

		Utilizator u = UtilizatorDAO.getUserById(Integer.parseInt(utilizatoriId));
		model.addAttribute("utilizator", u);

		return new ModelAndView("/utilizatori/detalii", "model", model);
	}

	@RequestMapping(value = "/utilizatori/editeaza/{utilizatoriId}")
	public ModelAndView editDetalii(@PathVariable String utilizatoriId, Model model)
			throws NumberFormatException, SQLException {

		Utilizator u = UtilizatorDAO.getUserById(Integer.parseInt(utilizatoriId));
		model.addAttribute("userForm", u);

		return new ModelAndView("/utilizatori/editeaza", "model", model);
	}

	@RequestMapping(value = "/utilizatori/save", method = RequestMethod.POST)
	public ModelAndView saveUser(@ModelAttribute("userForm") Utilizator utilizator, ModelMap model, BindingResult result) {

		Utilizator utilizatorObj;
		try {
		    utilizatorObj = UtilizatorDAO.getUserById(Integer.valueOf(utilizator.getId()));
			utilizatorObj.setNume(utilizator.getNume());
			utilizatorObj.setPrenume(utilizator.getPrenume());
			utilizatorObj.setAdresa(utilizator.getAdresa());
			utilizatorObj.setTelefon(utilizator.getTelefon());
			model.put("userForm", utilizator);
			
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return new ModelAndView("/users/edit", "command", utilizator);
	}

	@RequestMapping(value = "/users/stergere/{userId}")
	public ModelAndView deleteUser(@PathVariable String utilizatorId, Model model)
			throws NumberFormatException, SQLException {

		UtilizatorDAO.deleteUser(UtilizatorDAO.getUserById(Integer.parseInt(utilizatorId)));
		ArrayList<Utilizator> users = UtilizatorDAO.getUsers();
		model.addAttribute("usersList", users);

		return new ModelAndView("/utilizatori/listare", "model", model);
	}

	@RequestMapping(value = "/utilizatori/adauga")
	public ModelAndView adaugaUser(Model model) throws NumberFormatException, SQLException {

		Utilizator u = new Utilizator(0,null , null, null, null);
		model.addAttribute("userForm", u);

		return new ModelAndView("/utilizatori/add", "model", model);
	}

	@RequestMapping(value = "/utilizatori/addUser", method = RequestMethod.POST)
	public ModelAndView addUser(@ModelAttribute("userForm") Utilizator utilizator, ModelMap model, BindingResult result) {

		try {
			UtilizatorDAO.createUser(utilizator);
			model.put("userForm", utilizator);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}


		return new ModelAndView("redirect:/utilizatori.htm");
	}

}
