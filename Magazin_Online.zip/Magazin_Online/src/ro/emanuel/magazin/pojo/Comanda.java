package ro.emanuel.magazin.pojo;

public class Comanda {
	
	private int id;
	private int produsid;
	private int utilizatorid;
	private String data;
	
	
	
	public Comanda(int id, int produsid, int utilizatorid, String data) {
		super();
		this.id = id;
		this.produsid = produsid;
		this.utilizatorid = utilizatorid;
		this.data = data;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public int getProdusid() {
		return produsid;
	}



	public void setProdusid(int produsid) {
		this.produsid = produsid;
	}



	public int getUtilizatorid() {
		return utilizatorid;
	}



	public void setUtilizatorid(int utilizatorid) {
		this.utilizatorid = utilizatorid;
	}



	public String getData() {
		return data;
	}



	public void setData(String data) {
		this.data = data;
	}
	
	
	
	
	
	
	
	
	
}