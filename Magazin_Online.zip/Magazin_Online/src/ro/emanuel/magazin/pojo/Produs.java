package ro.emanuel.magazin.pojo;

public class Produs {
	
	private int id;
	private int utilizatorid;
	private String numeprodus;
	private int stoc;
	private int pret;

	
	public Produs(int id, int utilizatorid, String numeprodus, int stoc, int pret) {
		super();
		this.id = id;
		this.utilizatorid = utilizatorid;
		this.numeprodus = numeprodus;
		this.stoc = stoc;
		this.pret = pret;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getUtilizatorid() {
		return utilizatorid;
	}


	public void setUtilizatorid(int utilizatorid) {
		this.utilizatorid = utilizatorid;
	}


	public String getNumeprodus() {
		return numeprodus;
	}


	public void setNumeprodus(String numeprodus) {
		this.numeprodus = numeprodus;
	}


	public int getStoc() {
		return stoc;
	}


	public void setStoc(int stoc) {
		this.stoc = stoc;
	}


	public int getPret() {
		return pret;
	}


	public void setPret(int pret) {
		this.pret = pret;
	}
	
	
	
	
	
	
	
	
	
}	