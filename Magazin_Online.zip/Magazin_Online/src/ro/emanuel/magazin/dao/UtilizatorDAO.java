package ro.emanuel.magazin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import ro.emanuel.magazin.helper.DBHelper;
import ro.emanuel.magazin.pojo.Utilizator;

public class UtilizatorDAO {

	public static void createUser(Utilizator u) throws SQLException {
		Connection conn = DBHelper.createConnection();

		String insertString = "INSERT INTO utilizatori(nume, prenume, adresa,telefon) values(?,?,?,?)";

		PreparedStatement stmt = conn.prepareStatement(insertString);
		stmt.setString(1, u.getNume());
		stmt.setString(2, u.getPrenume());
		stmt.setString(3, u.getAdresa());
		stmt.setString(4, u.getTelefon());
		

		stmt.executeUpdate();

		DBHelper.closeConnection(conn);

	}

	public static void createUser(String nume, String prenume, String adresa, String telefon) throws SQLException {
		Utilizator u = new Utilizator(-1, nume, prenume, adresa, telefon);
		UtilizatorDAO.createUser(u);
	}

	public static ArrayList<Utilizator> getUsers() throws SQLException {
		ArrayList<Utilizator> result = new ArrayList<Utilizator>();
		Connection conn = DBHelper.createConnection();

		String selectString = "select * from utilizatori";
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(selectString);
		while (rs.next()) {
			int id = rs.getInt("id");
			String nume = rs.getString("nume");
			String prenume = rs.getString("prenume");
			String adresa = rs.getString("adresa");
			String telefon = rs.getString("telefon");
			Utilizator u = new Utilizator(id, nume, prenume, adresa,telefon);
			result.add(u);
		}
		DBHelper.closeConnection(conn);
		return result;
	}

	public static Utilizator getUserById(int userId) throws SQLException {
		Utilizator result = null;
		Connection conn = DBHelper.createConnection();

		String selectString = "select * from utilizatori where id=?";
		PreparedStatement stmt = conn.prepareStatement(selectString);
		stmt.setInt(1, userId);
		ResultSet rs = stmt.executeQuery();
		if (rs.next()) {
			int id = rs.getInt("id");
			String nume = rs.getString("nume");
			String prenume = rs.getString("prenume");
			String adresa = rs.getString("adresa");
			String telefon = rs.getString("telefon");
			result = new Utilizator(id, nume, prenume, adresa,telefon);
		}
		DBHelper.closeConnection(conn);
		return result;
	}

	public static void updateUser(Utilizator u) throws SQLException {
		Connection conn = DBHelper.createConnection();

		String updateString = "UPDATE utilizatori SET nume=?, prenume=?, adresa=?,telefon=? where id=?";

		PreparedStatement stmt = conn.prepareStatement(updateString);
		stmt.setString(1, u.getNume());
		stmt.setString(2, u.getPrenume());
		stmt.setString(3, u.getAdresa());
		stmt.setString(4, u.getTelefon());
		stmt.setInt(5, u.getId());

		stmt.executeUpdate();

		DBHelper.closeConnection(conn);
	}

	public static void deleteUser(Utilizator u) throws SQLException {
		Connection conn = DBHelper.createConnection();

		String deleteString = "DELETE from utilizatori where id=?";

		PreparedStatement stmt = conn.prepareStatement(deleteString);
		stmt.setInt(1, u.getId());

		stmt.executeUpdate();

		DBHelper.closeConnection(conn);
	}
}
