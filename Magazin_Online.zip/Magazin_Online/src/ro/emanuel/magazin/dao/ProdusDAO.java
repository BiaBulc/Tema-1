package ro.emanuel.magazin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import ro.emanuel.magazin.helper.DBHelper;
import ro.emanuel.magazin.pojo.Produs;


public class ProdusDAO {
	public static void createProduct(Produs p) throws SQLException {
		Connection conn = DBHelper.createConnection();

		String insertString = "INSERT INTO produse(utilizatorid, numeprodus, stoc, pret) values(?,?,?,?)";

		PreparedStatement stmt = conn.prepareStatement(insertString);
		stmt.setInt(1, p.getUtilizatorid());
		stmt.setString(2, p.getNumeprodus());
		stmt.setInt(3, p.getStoc());
		stmt.setInt(4, p.getPret());

		stmt.executeUpdate();

		DBHelper.closeConnection(conn);

	}
	public static void createProduct(int utilizatorid, String numeprodus, int stoc, int pret) throws SQLException {
		Produs p = new Produs(4, utilizatorid, numeprodus, stoc,pret);
		ProdusDAO.createProduct(p);
	}

	public static ArrayList<Produs> getProducts() throws SQLException {
		ArrayList<Produs> result = new ArrayList<Produs>();
		Connection conn = DBHelper.createConnection();

		String selectString = "select * from produse";
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(selectString);
		while (rs.next()) {
			int id = rs.getInt("id");
			int utilizatorid = rs.getInt("utilizatorid");
			String numeprodus = rs.getString("numeprodus");
			int stoc = rs.getInt("stoc");
			int pret = rs.getInt("pret");
			Produs p = new Produs(id, utilizatorid, numeprodus, stoc, pret);
			result.add(p);
		}
		DBHelper.closeConnection(conn);
		return result;
	}

	public static void updateProduct(Produs p) throws SQLException {
		Connection conn = DBHelper.createConnection();

		String updateString = "UPDATE produse SET utilizatorid=?, numeprodus=?, stoc=?, pret=? where id=?";

		PreparedStatement stmt = conn.prepareStatement(updateString);
		stmt.setInt(1, p.getUtilizatorid());
		stmt.setString(2, p.getNumeprodus());
		stmt.setInt(3, p.getStoc());
		stmt.setInt(4, p.getPret());

		stmt.executeUpdate();

		DBHelper.closeConnection(conn);
	}

	public static Produs getProductById(int productId) throws SQLException {
		Produs result = null;
		Connection conn = DBHelper.createConnection();

		String selectString = "select * from produse where id=?";
		PreparedStatement stmt = conn.prepareStatement(selectString);
		stmt.setInt(1, productId);
		ResultSet rs = stmt.executeQuery();
		if (rs.next()) {
			int id = rs.getInt("id");
			int utilizatorid = rs.getInt("utilizatorid");
			String numeprodus = rs.getString("numeprodus");
			int stoc = rs.getInt("stoc");
			int pret= rs.getInt("pret");
			result = new Produs(id, utilizatorid,numeprodus,stoc,pret);
		}
		DBHelper.closeConnection(conn);
		return result;
	}

	public static void deleteProduct(Produs p) throws SQLException {
		Connection conn = DBHelper.createConnection();

		String deleteString = "DELETE from produse where id=?";

		PreparedStatement stmt = conn.prepareStatement(deleteString);
		stmt.setInt(1, p.getId());

		stmt.executeUpdate();

		DBHelper.closeConnection(conn);
	}
}
