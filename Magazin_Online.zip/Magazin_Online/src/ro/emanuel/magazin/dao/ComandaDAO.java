package ro.emanuel.magazin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import ro.emanuel.magazin.helper.DBHelper;
import ro.emanuel.magazin.pojo.Comanda;

public class ComandaDAO {
	public static void createOrder(Comanda o) throws SQLException {
		Connection conn = DBHelper.createConnection();

		String insertString = "INSERT INTO comenzi(produsid,utilizatorid,data) values(?,?,?)";

		PreparedStatement stmt = conn.prepareStatement(insertString);
		stmt.setInt(1, o.getProdusid());
		stmt.setInt(2, o.getUtilizatorid());
		stmt.setString(3, o.getData());

		stmt.executeUpdate();

		DBHelper.closeConnection(conn);

	}

	public static ArrayList<Comanda> getOrders() throws SQLException {
		ArrayList<Comanda> result = new ArrayList<Comanda>();
		Connection conn = DBHelper.createConnection();

		String selectString = "select * from comenzi";
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(selectString);
		while (rs.next()) {
			int id = rs.getInt("id");
			int produsid = rs.getInt("produsid");
			int utilizatorid = rs.getInt("utilizatorid");
			String data = rs.getString("data");
			Comanda o = new Comanda(id, produsid,utilizatorid,data);
			result.add(o);
		}
		DBHelper.closeConnection(conn);
		return result;
	}

	public static void updateOrder(Comanda o) throws SQLException {
		Connection conn = DBHelper.createConnection();

		String updateString = "UPDATE comenzi SET produsid=?, utilizatorid=?, data=? where id=?";

		PreparedStatement stmt = conn.prepareStatement(updateString);
		stmt.setInt(1, o.getProdusid());
		stmt.setInt(2, o.getUtilizatorid());
		stmt.setString(3, o.getData());
		stmt.setInt(4, o.getId());

		stmt.executeUpdate();

		DBHelper.closeConnection(conn);
	}

	public static Comanda getOrderById(int orderId) throws SQLException {
		Comanda result = null;
		Connection conn = DBHelper.createConnection();

		String selectString = "select * from comenzi where id=?";
		PreparedStatement stmt = conn.prepareStatement(selectString);
		stmt.setInt(1, orderId);
		ResultSet rs = stmt.executeQuery();
		if (rs.next()) {
			
			int id = rs.getInt("id");
			int produsid = rs.getInt("produsid");
			int utilizatorid = rs.getInt("utilizatorid");
			String data = rs.getString("data");
			result = new Comanda(id, produsid,utilizatorid,data);
			
		}
		DBHelper.closeConnection(conn);
		return result;
	}

	public static void deleteOrder(Comanda o) throws SQLException {
		Connection conn = DBHelper.createConnection();

		String deleteString = "DELETE from comenzi where id=?";

		PreparedStatement stmt = conn.prepareStatement(deleteString);
		stmt.setInt(1, o.getId());

		stmt.executeUpdate();

		DBHelper.closeConnection(conn);
	}
}
